import React, { Component } from 'react';

export default class Header  extends Component {
  render() {
    return (
      <header>
         <span>请求头信息</span>
      </header>
    );
  }
};

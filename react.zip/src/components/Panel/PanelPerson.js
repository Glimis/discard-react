import React, { Component } from 'react';
import Panel from './Panel'
export default class PanelPerson  extends Component {
  render() {
    return (
      <Panel title="团队成员">
         <span>1</span>
      </Panel>
    );
  }
};

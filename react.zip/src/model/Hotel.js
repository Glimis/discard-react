import { observable } from 'mobx';
import {Model} from 'Common'
export default class Hotel extends Model{

    constructor(obj={}) {
        super(obj);
    }

}

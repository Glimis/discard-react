import { observable } from 'mobx';
import {Model} from 'Common'
export default class Order extends Model{

    constructor(obj={}) {
        super(obj);
    }

}

import {Store} from 'Common'

export default  class Hotel extends Store{
    constructor(obj=[]) {
        super(obj);
    }
}

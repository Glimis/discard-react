import {Store} from 'Common'

export default  class Order extends Store{
  
  constructor(obj={}) {
    super(obj);
  }


}


